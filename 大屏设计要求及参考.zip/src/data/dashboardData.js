export const processMetrics = {
  left: [
    { title: '渗沥液流量', rows: [{ label: '实际值', value: '64.2', unit: 'm³/h' }] },
    { title: '沼液和鲜污流量', rows: [{ label: '实际值', value: '18.6', unit: 'm³/h' }] },
    { title: '厌氧系统进水', rows: [{ label: 'COD', value: '4860', unit: 'mg/L' }, { label: 'NH3-N', value: '224', unit: 'mg/L' }] },
    { title: '厌氧罐参数', rows: [{ label: '温度', value: '36.8', unit: '℃' }, { label: '压力', value: '0.12', unit: 'MPa' }] }
  ],
  right: [
    { title: '厌氧进水超越至二级反硝化流量', rows: [{ label: '实际值', value: '9.8', unit: 'm³/h' }, { label: '预测值', value: '10.2', unit: 'm³/h', warn: true }] },
    { title: '超滤系统出水', rows: [{ label: 'COD 设定值', value: '450', unit: 'mg/L' }, { label: 'COD 实际值', value: '418', unit: 'mg/L' }, { label: 'NH3-N 实际值', value: '22', unit: 'mg/L' }] },
    { title: '超滤系统流量参数', rows: [{ label: '循环流量', value: '74.2', unit: 'm³/h' }, { label: '产水流量', value: '42.9', unit: 'm³/h' }] }
  ]
};

export const gauges = [
  { label: '昨日晚班', value: '00.00%' },
  { label: '今日早班', value: '16.00%' },
  { label: '今日中班', value: '00.00%' }
];

export const chartPanels = [
  '功率统计',
  '厌氧系统进水',
  '厌氧系统出水',
  '一级硝化系统出水',
  '二级硝化系统出水',
  '超滤系统出水'
].map((title, index) => ({
  title,
  unit: index === 0 ? 'kW' : 'mg/L',
  blue: makeLine(index * 0.9, 0),
  gold: makeLine(index * 0.6, 18),
  green: index === 5 ? '0,66 260,66' : ''
}));

export const evaluationParameters = [
  { key: 'inCodActual', label: '进口COD实际', unit: 'mg/L' },
  { key: 'inCodModel', label: '进口COD化验', unit: 'mg/L' },
  { key: 'codAvg', label: 'COD平均', unit: 'mg/L' },
  { key: 'outCod', label: '出口COD', unit: 'mg/L' },
  { key: 'inNh3n', label: '进口NH3-N', unit: 'mg/L' },
  { key: 'outNh3n', label: '出口NH3-N', unit: 'mg/L' },
  { key: 'codRemoval', label: 'COD去除率', unit: '%' },
  { key: 'nh3nRemoval', label: 'NH₃-N去除率', unit: '%' },
  { key: 'inFlow', label: '进水量', unit: 'm³' },
  { key: 'doAvg', label: 'DO均值', unit: '' },
  { key: 'doVariance', label: 'DO方差', unit: '' },
  { key: 'operationRate', label: '投运率', unit: '%' },
  { key: 'temperature', label: '温度', unit: '℃' },
  { key: 'power', label: '电耗', unit: 'kWh' },
  { key: 'unitPower', label: '单位电耗', unit: 'kWh/m³' }
];

export const evaluationRows = ['2025.9', '2025.10', '2025.11', '2025.12', '2026.1', '2026.2'].map((month, rowIndex) => {
  const values = {};
  evaluationParameters.forEach((item, index) => {
    const base = [4820, 4910, 4865, 418, 224, 22, 82, 90, 18600, 2.8, 0.32, 91, 26, 68500, 5.42][index];
    const delta = Math.sin((rowIndex + 1) * (index + 2) / 3) * (index < 6 ? 80 : 3);
    values[item.key] = Number(base + delta + rowIndex * (index < 6 ? 16 : 0.18)).toFixed(index < 6 || index === 13 ? 0 : 2);
  });
  return { month, values };
});

export const targetItems = [
  { id: 1, label: '厌氧进水流量', unit: 'm³/h', value: '62.0' },
  { id: 2, label: '厌氧出水COD', unit: 'mg/L', value: '3400' },
  { id: 3, label: '一级生化出水COD', unit: 'mg/L', value: '820' },
  { id: 4, label: '二级生化出水COD', unit: 'mg/L', value: '460' },
  { id: 5, label: '厌氧出水NH3-N', unit: 'mg/L', value: '180' },
  { id: 6, label: '一级生化出水NH3-N', unit: 'mg/L', value: '54' },
  { id: 7, label: '二级生化出水NH3-N', unit: 'mg/L', value: '25' },
  { id: 8, label: '电耗最低', unit: '', value: '' }
];

export const learningTasks = Array.from({ length: 10 }, (_, index) => ({
  id: index + 1,
  checked: index === 0,
  start: index % 2 === 0 ? '2025-08-06 08:59:00' : '2025-08-08 08:59:00',
  end: index % 2 === 0 ? '2025-08-08 08:59:00' : '2025-08-06 08:59:00',
  status: '未操作'
}));

export const operationMonths = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月', '全年'];
export const operationRates = [86, 72, 81, 90, 87, 74, 83, 91, 88, 76, 84, 92, 86];

export const debugConfigRows = [
  '溶解氧最小值',
  '溶解氧最大值',
  '超滤COD限值',
  '超滤NH₃-N限值',
  '一级曝气风机流量计算值权重',
  '一级曝气风机流量预测值权重',
  '一级射流泵流量计算值权重',
  '一级射流泵流量预测值权重',
  '二级曝气风机流量计算值权重',
  '二级曝气风机流量预测值权重'
].map((name, index) => ({
  name,
  value: index === 2 ? '450' : index === 3 ? '25' : '',
  unit: index === 2 || index === 3 ? 'mg/L' : '—'
}));

export const debugOutputRows = [
  ['厌氧进水流量预测值', 'm³/h'],
  ['一级曝气流量预测值', 'm³/h'],
  ['二级曝气流量预测值', 'm³/h'],
  ['曝气风机流量计算值', 'm³/h'],
  ['曝气风机流量寻优值', 'm³/h'],
  ['一级射流泵流量预测值', 'm³/h'],
  ['一级射流泵流量计算值', 'm³/h'],
  ['一级射流泵流量寻优值', 'm³/h'],
  ['DO预测值', '—'],
  ['曝气风机寻优功率', 'kW'],
  ['一级射流泵寻优功率', 'kW'],
  ['寻优总功率', 'kW']
].map(([name, unit], index) => ({ name, value: index % 3 === 0 ? '42.6' : '', unit }));

function makeLine(seed = 0, offset = 0) {
  return Array.from({ length: 9 }, (_, index) => {
    const x = index * 32;
    const y = 82 - Math.sin(index * 1.05 + seed) * 20 - index * 3 + offset;
    return `${x},${Math.max(16, Math.min(104, y)).toFixed(1)}`;
  }).join(' ');
}
