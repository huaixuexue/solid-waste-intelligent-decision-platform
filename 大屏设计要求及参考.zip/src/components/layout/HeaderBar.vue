<template>
  <header class="top-layout">
    <section class="brand-zone">
      <div class="logo-mark">五矿</div>
      <div class="brand-copy">
        <strong>中国恩菲工程技术有限公司</strong>
        <span>CHINA ENFI ENGINEERING CORPORATION</span>
      </div>
      <nav class="view-tabs" aria-label="主模块切换">
        <button
          type="button"
          :class="{ active: activeView === 'monitor' }"
          @click="$emit('changeView', 'monitor')"
        >
          系统监视
        </button>
        <button
          type="button"
          :class="{ active: activeView === 'evaluation' }"
          @click="$emit('changeView', 'evaluation')"
        >
          分析评估
        </button>
      </nav>
    </section>

    <section class="title-zone">
      <div class="time-line">17:52:00　2025-05-22　星期四</div>
      <h1>渗 沥 液 处 理 系 统</h1>
      <div class="title-glow"></div>
    </section>

    <section class="status-zone">
      <strong>中国恩菲黑灯工厂</strong>
      <div class="env">
        厂区环境：
        <span>温度 <b>26℃</b></span>
        <span>湿度 <b>45%</b></span>
      </div>
      <div class="header-actions">
        <button type="button" @click="$emit('openModal', 'target')">目标寻优</button>
        <button type="button" @click="$emit('openModal', 'learning')">自学习</button>
        <button type="button" @click="$emit('openModal', 'debug')">调试</button>
      </div>
    </section>
  </header>
</template>

<script setup>
defineProps({
  activeView: {
    type: String,
    required: true
  }
});

defineEmits(['changeView', 'openModal']);
</script>
