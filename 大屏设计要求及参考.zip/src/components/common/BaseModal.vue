<template>
  <div class="modal-mask" @click.self="$emit('close')">
    <section class="modal-window" :class="size">
      <header class="modal-header">
        <h2>{{ title }}</h2>
        <button type="button" class="modal-close" @click="$emit('close')">×</button>
      </header>
      <div class="modal-body">
        <slot></slot>
      </div>
      <footer v-if="$slots.footer" class="modal-footer">
        <slot name="footer"></slot>
      </footer>
    </section>
  </div>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true
  },
  size: {
    type: String,
    default: 'large'
  }
});

defineEmits(['close']);
</script>
