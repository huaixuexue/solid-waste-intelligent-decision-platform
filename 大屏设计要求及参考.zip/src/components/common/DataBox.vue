<template>
  <section class="data-box">
    <h3>{{ title }}</h3>
    <div
      v-for="row in rows"
      :key="row.label"
      class="data-row"
      :class="{ warning: row.warn }"
    >
      <span>{{ row.label }}</span>
      <b>{{ row.value }}</b>
      <em>{{ row.unit }}</em>
    </div>
  </section>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true
  },
  rows: {
    type: Array,
    required: true
  }
});
</script>
