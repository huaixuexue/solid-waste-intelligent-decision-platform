<template>
  <section class="panel chart-card">
    <div class="panel-title">{{ title }}</div>
    <div class="chart-tabs">
      <span class="active">COD</span>
      <span>NH₃-N</span>
    </div>
    <svg viewBox="0 0 260 138" preserveAspectRatio="none" class="mini-chart" aria-hidden="true">
      <path d="M10 118H252 M10 92H252 M10 66H252 M10 40H252 M10 14H252" class="grid-line" />
      <path d="M10 14V118 H252" class="axis-line" />
      <polyline :points="blue" class="line-blue" />
      <polyline :points="gold" class="line-gold" />
      <polyline v-if="green" :points="green" class="line-green" />
      <polygon :points="`0,138 ${blue} 260,138`" class="area-blue" />
    </svg>
    <div class="chart-legend">
      <span class="blue">实际值</span>
      <span class="gold">预测值</span>
    </div>
  </section>
</template>

<script setup>
defineProps({
  title: {
    type: String,
    required: true
  },
  blue: {
    type: String,
    required: true
  },
  gold: {
    type: String,
    required: true
  },
  green: {
    type: String,
    default: ''
  }
});
</script>
