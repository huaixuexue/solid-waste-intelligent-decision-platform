<template>
  <section class="panel rate-panel">
    <div class="panel-title">
      <span>LTIC 投用率</span>
      <button type="button" @click="$emit('openRate')">实时</button>
    </div>
    <div class="gauge-list">
      <button
        v-for="item in gauges"
        :key="item.label"
        type="button"
        class="gauge-item"
        @click="$emit('openRate')"
      >
        <i :style="{ '--rate': item.value }">{{ item.value }}</i>
        <span>{{ item.label }}</span>
      </button>
    </div>
  </section>
</template>

<script setup>
defineProps({
  gauges: {
    type: Array,
    required: true
  }
});

defineEmits(['openRate']);
</script>
