<template>
  <section class="process-flow">
    <svg viewBox="0 0 1160 520" preserveAspectRatio="none" aria-hidden="true">
      <defs>
        <linearGradient id="pipeBlue" x1="0" x2="1">
          <stop offset="0" stop-color="#1a65ff" />
          <stop offset=".5" stop-color="#4da7ff" />
          <stop offset="1" stop-color="#1d6cff" />
        </linearGradient>
        <linearGradient id="pipeGreen" x1="0" x2="1">
          <stop offset="0" stop-color="#1b8e56" />
          <stop offset=".5" stop-color="#40d178" />
          <stop offset="1" stop-color="#1c8950" />
        </linearGradient>
      </defs>
      <path class="pipe blue" d="M18 56H160C174 56 184 66 184 80V230" />
      <path class="pipe blue" d="M22 198H160C174 198 184 208 184 222V354H350V240H510V310H650V206H822V288H1080" />
      <path class="pipe blue" d="M330 56H860C874 56 884 66 884 80V372H1040" />
      <path class="pipe blue" d="M350 354H330C316 354 306 344 306 330V292H214" />
      <path class="pipe green" d="M620 176H980C994 176 1004 186 1004 200V330" />
      <path class="thin-pipe" d="M508 240V94H638V176" />
      <path class="thin-pipe" d="M654 204V420H820" />
      <text x="74" y="61" class="pipe-arrow">›››</text>
      <text x="74" y="203" class="pipe-arrow">›››</text>
      <text x="416" y="60" class="pipe-arrow">›››</text>
      <text x="742" y="60" class="pipe-arrow">›››</text>
      <text x="456" y="313" class="pipe-arrow">›››</text>
      <text x="718" y="182" class="pipe-arrow reverse">‹‹‹</text>
      <text x="916" y="293" class="pipe-arrow">›››</text>
    </svg>

    <div class="valve" style="left:80px;top:30px;"></div>
    <div class="valve" style="left:76px;top:173px;"></div>
    <div class="valve" style="left:300px;top:366px;"></div>
    <div class="valve" style="left:872px;top:88px;"></div>
    <div class="valve" style="left:1060px;top:336px;"></div>

    <div class="tank square" style="left:56px;top:258px;width:146px;height:102px;">调节池</div>
    <div class="pump" style="left:246px;top:282px;"></div>
    <div class="tank anaerobic" style="left:382px;top:146px;width:126px;height:226px;">厌氧罐</div>
    <div class="pump" style="left:420px;top:384px;"></div>
    <div class="tank pool" style="left:594px;top:178px;width:146px;height:94px;">一级反硝化池</div>
    <div class="tank pool" style="left:594px;top:332px;width:146px;height:94px;">一级硝化池</div>
    <div class="tank pool" style="left:824px;top:172px;width:146px;height:94px;">二级反硝化池</div>
    <div class="tank pool" style="left:824px;top:332px;width:146px;height:94px;">二级硝化池</div>
    <div class="blower" style="left:504px;top:378px;"></div>
    <div class="blower" style="left:742px;top:280px;"></div>
    <div class="filter-device" style="left:1018px;top:282px;">
      <div class="filter-tower"></div>
      <div class="filter-tower small"></div>
      <strong>超滤系统</strong>
    </div>

    <div class="tag" style="left:126px;top:150px;">1</div>
    <div class="tag" style="left:405px;top:120px;">2</div>
    <div class="tag" style="left:432px;top:120px;">3</div>
    <div class="tag" style="left:458px;top:120px;">4</div>
    <div class="tag" style="left:572px;top:120px;">5</div>
    <div class="tag" style="left:600px;top:120px;">6</div>
    <div class="tag" style="left:694px;top:282px;">9</div>
    <div class="tag" style="left:922px;top:72px;">14</div>
    <div class="tag" style="left:1052px;top:240px;">15</div>

    <div class="flow-box compact" style="left:8px;top:86px;">
      <h4>渗沥液流量</h4>
      <p><span>实际值</span><b>64.2</b><em>m³/h</em></p>
    </div>
    <div class="flow-box compact" style="left:226px;top:62px;">
      <h4>厌氧系统进水</h4>
      <p><span>COD</span><b>4860</b><em>mg/L</em></p>
      <p><span>NH3-N</span><b>224</b><em>mg/L</em></p>
    </div>
    <div class="flow-box compact" style="left:526px;top:76px;">
      <h4>厌氧系统出水</h4>
      <p><span>实际值</span><b>3420</b><em>mg/L</em></p>
      <p><span>预测值</span><b>3368</b><em>mg/L</em></p>
    </div>
    <div class="flow-box compact" style="left:712px;top:88px;">
      <h4>厌氧进水超越至缺氧流量</h4>
      <p><span>实际值</span><b>9.8</b><em>m³/h</em></p>
      <p><span>预测值</span><b>10.2</b><em>m³/h</em></p>
    </div>
    <div class="flow-box compact" style="left:940px;top:84px;">
      <h4>厌氧进水超越至二级反硝化流量</h4>
      <p><span>实际值</span><b>7.4</b><em>m³/h</em></p>
      <p><span>预测值</span><b>7.8</b><em>m³/h</em></p>
    </div>
    <div class="flow-box compact" style="left:712px;top:276px;">
      <h4>一级硝化风机流量</h4>
      <p><span>实际值</span><b>320</b><em>m³/h</em></p>
      <p><span>预测值</span><b>336</b><em>m³/h</em></p>
    </div>
    <div class="flow-box compact" style="left:486px;top:420px;">
      <h4>一级硝化池参数</h4>
      <p><span>温度</span><b>27.2</b><em>℃</em></p>
      <p><span>溶解氧DO</span><b>2.8</b><em></em></p>
    </div>
    <div class="flow-box compact" style="left:918px;top:420px;">
      <h4>二级生化系统出水</h4>
      <p><span>COD</span><b>418</b><em>mg/L</em></p>
      <p><span>NH3-N</span><b>22</b><em>mg/L</em></p>
    </div>
  </section>
</template>
