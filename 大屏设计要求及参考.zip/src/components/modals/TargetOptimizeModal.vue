<template>
  <BaseModal title="目标寻优" size="medium" @close="$emit('close')">
    <div class="target-modal">
      <section class="target-group">
        <div class="target-card">
          <label>
            <input type="checkbox" checked />
            <span>溶解氧</span>
          </label>
          <div class="target-limit">
            <b>最大值</b>
            <input value="3.50" />
          </div>
          <div class="target-limit">
            <b>最小值</b>
            <input value="2.00" />
          </div>
        </div>
        <div class="target-card compact">
          <label>
            <input type="checkbox" checked />
            <span>超滤出水COD</span>
          </label>
          <div class="target-limit">
            <input value="450" />
            <em>mg/L</em>
          </div>
        </div>
        <div class="target-card compact">
          <label>
            <input type="checkbox" />
            <span>超滤出水NH₃-N</span>
          </label>
          <div class="target-limit disabled">
            <input disabled placeholder="未勾选不可编辑" />
            <em>mg/L</em>
          </div>
        </div>
      </section>

      <section class="target-list panel">
        <div
          v-for="item in targetItems"
          :key="item.id"
          class="target-row"
        >
          <label>
            <input type="checkbox" :checked="item.id < 4" />
            <span>{{ item.label }}</span>
          </label>
          <input :value="item.value" :disabled="item.id >= 4" placeholder="请输入" />
          <em>{{ item.unit }}</em>
        </div>
      </section>
    </div>

    <template #footer>
      <button type="button" class="btn ghost" @click="$emit('close')">取消</button>
      <button type="button" class="btn primary" @click="$emit('close')">确定</button>
    </template>
  </BaseModal>
</template>

<script setup>
import BaseModal from '../common/BaseModal.vue';
import { targetItems } from '../../data/dashboardData';

defineEmits(['close']);
</script>
