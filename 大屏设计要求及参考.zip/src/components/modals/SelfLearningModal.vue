<template>
  <BaseModal title="自学习" size="wide" @close="$emit('close')">
    <div class="learning-toolbar">
      <label>选择日期：</label>
      <input value="2025-08-06" />
      <span>~</span>
      <input value="2025-08-08" />
      <button type="button" class="btn primary small">+ 添加</button>
      <button type="button" class="btn ghost small">重置</button>
      <button type="button" class="btn danger small">批量删除</button>
      <button type="button" class="btn primary small">批量自学习</button>
    </div>

    <table class="modal-table">
      <thead>
        <tr>
          <th><input type="checkbox" checked /></th>
          <th>开始日期</th>
          <th>结束日期</th>
          <th>操作状态</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="task in learningTasks"
          :key="task.id"
          :class="{ selected: task.checked }"
        >
          <td><input type="checkbox" :checked="task.checked" /></td>
          <td>{{ task.start }}</td>
          <td>{{ task.end }}</td>
          <td>{{ task.status }}</td>
          <td><a>自学习</a><span>|</span><a class="danger-link">删除</a></td>
        </tr>
      </tbody>
    </table>

    <div class="pagination">
      <span>共10条数据</span>
      <button class="page active">1</button>
      <button class="page">2</button>
      <button class="page">3</button>
      <button class="page">4</button>
      <button class="page">5</button>
      <button class="page">6</button>
      <button class="page">7</button>
      <button class="page">8</button>
      <button class="page">9</button>
      <select><option>10条/页</option></select>
      <span>跳至</span>
      <input value="5" />
      <span>页</span>
    </div>

    <template #footer>
      <button type="button" class="btn ghost" @click="$emit('close')">取消</button>
      <button type="button" class="btn primary" @click="$emit('close')">下载</button>
    </template>
  </BaseModal>
</template>

<script setup>
import BaseModal from '../common/BaseModal.vue';
import { learningTasks } from '../../data/dashboardData';

defineEmits(['close']);
</script>
