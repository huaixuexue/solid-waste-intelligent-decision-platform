<template>
  <BaseModal title="投运率" size="wide" @close="$emit('close')">
    <div class="rate-query">
      <button type="button" class="btn primary">查询</button>
      <label>
        年份
        <select>
          <option>2025年</option>
          <option>2026年</option>
        </select>
      </label>
      <button type="button" class="btn primary">下载</button>
    </div>

    <table class="rate-table">
      <thead>
        <tr>
          <th v-for="month in operationMonths" :key="month">{{ month }}</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td v-for="value in operationRates" :key="value">{{ value }}%</td>
        </tr>
      </tbody>
    </table>

    <section class="rate-chart">
      <h3>系列 1</h3>
      <svg viewBox="0 0 900 330" preserveAspectRatio="none" aria-hidden="true">
        <path d="M42 292H880 M42 235H880 M42 178H880 M42 121H880 M42 64H880" class="grid-line" />
        <g>
          <rect
            v-for="(value, index) in operationRates"
            :key="index"
            :x="62 + index * 62"
            :y="292 - value * 2.3"
            width="18"
            :height="value * 2.3"
            class="bar-green"
          />
        </g>
      </svg>
    </section>
  </BaseModal>
</template>

<script setup>
import BaseModal from '../common/BaseModal.vue';
import { operationMonths, operationRates } from '../../data/dashboardData';

defineEmits(['close']);
</script>
