<template>
  <BaseModal title="调试界面" size="fullscreen" @close="$emit('close')">
    <div class="debug-modal">
      <section class="debug-table panel">
        <h3>配置参数</h3>
        <table>
          <tbody>
            <tr v-for="row in debugConfigRows" :key="row.name">
              <td>{{ row.name }}</td>
              <td><input :value="row.value" /></td>
              <td>{{ row.unit }}</td>
              <td><button type="button">确定</button></td>
            </tr>
          </tbody>
        </table>
      </section>

      <section class="debug-table panel">
        <h3>输出参数</h3>
        <table>
          <tbody>
            <tr v-for="row in debugOutputRows" :key="row.name">
              <td>{{ row.name }}</td>
              <td><input :value="row.value" readonly /></td>
              <td>{{ row.unit }}</td>
            </tr>
          </tbody>
        </table>
      </section>

      <section class="debug-history">
        <h3>历史数据</h3>
        <article class="debug-chart panel">
          <h4>坐标轴标题</h4>
          <svg viewBox="0 0 540 190" preserveAspectRatio="none" aria-hidden="true">
            <path d="M42 156H500 M42 118H500 M42 80H500 M42 42H500" class="grid-line" />
            <polyline points="70,56 138,122 206,82 274,42 342,48 410,92 478,126" class="line-blue" />
          </svg>
        </article>
        <article class="debug-chart panel">
          <h4>坐标轴标题</h4>
          <svg viewBox="0 0 540 190" preserveAspectRatio="none" aria-hidden="true">
            <path d="M42 156H500 M42 118H500 M42 80H500 M42 42H500" class="grid-line" />
            <polyline points="70,56 138,122 206,82 274,42 342,48 410,92 478,126" class="line-blue" />
          </svg>
        </article>
      </section>
    </div>
  </BaseModal>
</template>

<script setup>
import BaseModal from '../common/BaseModal.vue';
import { debugConfigRows, debugOutputRows } from '../../data/dashboardData';

defineEmits(['close']);
</script>
