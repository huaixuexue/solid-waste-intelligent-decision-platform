<template>
  <div class="app-shell">
    <section class="dashboard-frame">
      <HeaderBar
        :active-view="activeView"
        @change-view="activeView = $event"
        @open-modal="openModal"
      />

      <main class="screen-content">
        <MonitorView
          v-if="activeView === 'monitor'"
          @open-modal="openModal"
        />
        <EvaluationView
          v-else
          @open-modal="openModal"
        />
      </main>
    </section>

    <TargetOptimizeModal v-if="activeModal === 'target'" @close="closeModal" />
    <SelfLearningModal v-if="activeModal === 'learning'" @close="closeModal" />
    <OperationRateModal v-if="activeModal === 'rate'" @close="closeModal" />
    <DebugModal v-if="activeModal === 'debug'" @close="closeModal" />
  </div>
</template>

<script setup>
import { ref } from 'vue';
import HeaderBar from './components/layout/HeaderBar.vue';
import MonitorView from './views/MonitorView.vue';
import EvaluationView from './views/EvaluationView.vue';
import TargetOptimizeModal from './components/modals/TargetOptimizeModal.vue';
import SelfLearningModal from './components/modals/SelfLearningModal.vue';
import OperationRateModal from './components/modals/OperationRateModal.vue';
import DebugModal from './components/modals/DebugModal.vue';

const activeView = ref('monitor');
const activeModal = ref(null);

function openModal(name) {
  activeModal.value = name;
}

function closeModal() {
  activeModal.value = null;
}
</script>
