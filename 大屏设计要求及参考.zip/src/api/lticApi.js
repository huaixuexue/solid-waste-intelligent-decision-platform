const API_BASE = import.meta.env.VITE_API_BASE_URL || '/api';

async function request(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    ...options
  });

  if (!response.ok) {
    throw new Error(`API request failed: ${response.status}`);
  }

  return response.json();
}

export const lticApi = {
  getMonitorSnapshot() {
    return request('/ltic/monitor');
  },
  getEvaluation(params) {
    const query = new URLSearchParams(params).toString();
    return request(`/ltic/evaluation?${query}`);
  },
  saveTargetOptimization(payload) {
    return request('/ltic/target-optimization', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },
  createSelfLearningTask(payload) {
    return request('/ltic/self-learning/tasks', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  },
  getOperationRate(year) {
    return request(`/ltic/operation-rate?year=${year}`);
  },
  saveDebugParameter(payload) {
    return request('/ltic/debug/parameters', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }
};
