<template>
  <section class="evaluation-view">
    <div class="eval-toolbar">
      <button type="button">时间选取</button>
      <button type="button">参数选取</button>
      <button type="button" @click="$emit('openModal', 'rate')">投运率</button>
      <button type="button">下载</button>
    </div>

    <section class="eval-table panel">
      <table>
        <thead>
          <tr>
            <th>时间</th>
            <th v-for="item in evaluationParameters" :key="item.key">{{ item.label }}</th>
          </tr>
          <tr>
            <th>单位</th>
            <th v-for="item in evaluationParameters" :key="item.key">{{ item.unit }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in evaluationRows" :key="row.month">
            <td>{{ row.month }}</td>
            <td v-for="item in evaluationParameters" :key="item.key">{{ row.values[item.key] }}</td>
          </tr>
        </tbody>
      </table>
    </section>

    <section class="eval-charts">
      <article
        v-for="chart in evalCharts"
        :key="chart.title"
        class="eval-chart panel"
      >
        <h3>{{ chart.title }}</h3>
        <svg viewBox="0 0 260 118" preserveAspectRatio="none" aria-hidden="true">
          <path d="M16 96H248 M16 68H248 M16 40H248 M16 12H248" class="grid-line" />
          <polyline :points="chart.lineA" class="line-blue" />
          <polyline :points="chart.lineB" class="line-gold" />
          <polyline v-if="chart.lineC" :points="chart.lineC" class="line-orange" />
          <g v-if="chart.bars">
            <rect
              v-for="bar in chart.bars"
              :key="bar.x"
              :x="bar.x"
              :y="bar.y"
              :width="bar.width"
              :height="bar.height"
              class="bar-blue"
            />
          </g>
        </svg>
      </article>
    </section>
  </section>
</template>

<script setup>
import { evaluationParameters, evaluationRows } from '../data/dashboardData';

defineEmits(['openModal']);

const evalCharts = [
  makeEvalChart('进出口COD', 0),
  makeEvalChart('进出口NH₃-N', 1),
  makeEvalChart('去除率', 2, true),
  makeEvalChart('进水量', 3, true),
  makeEvalChart('DO均值及方差', 4),
  makeEvalChart('投运率', 5, true),
  makeEvalChart('温度', 6, true),
  makeEvalChart('电耗', 7, false, true),
  makeEvalChart('单位电耗', 8, true),
  makeEvalChart('曝气风机电耗', 9, true)
];

function makeEvalChart(title, seed, withThird = false, bars = false) {
  return {
    title,
    lineA: makeLine(seed, 0),
    lineB: makeLine(seed + 1.6, 12),
    lineC: withThird ? makeLine(seed + 2.8, 22) : '',
    bars: bars ? Array.from({ length: 5 }, (_, index) => ({
      x: 32 + index * 42,
      y: 30 + (index % 2) * 18,
      width: 16,
      height: 66 - (index % 3) * 12
    })) : null
  };
}

function makeLine(seed, offset) {
  return Array.from({ length: 5 }, (_, index) => {
    const x = 22 + index * 54;
    const y = 70 - Math.sin(index + seed) * 20 + offset;
    return `${x},${Math.max(16, Math.min(98, y)).toFixed(1)}`;
  }).join(' ');
}
</script>
