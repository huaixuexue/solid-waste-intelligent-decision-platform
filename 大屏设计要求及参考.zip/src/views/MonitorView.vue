<template>
  <section class="monitor-view">
    <aside class="monitor-left">
      <DataBox
        v-for="item in processMetrics.left"
        :key="item.title"
        :title="item.title"
        :rows="item.rows"
      />
      <GaugeGroup :gauges="gauges" @open-rate="$emit('openModal', 'rate')" />
    </aside>

    <ProcessFlow />

    <aside class="monitor-right">
      <DataBox
        v-for="item in processMetrics.right"
        :key="item.title"
        :title="item.title"
        :rows="item.rows"
      />
    </aside>

    <section class="energy-strip panel">
      <div class="panel-title">设备累计耗电量统计 <em>单位：(kW·h)</em></div>
      <div class="energy-cells">
        <span>厌氧循环泵1</span>
        <span>厌氧循环泵2</span>
        <span>一级罗茨风机1</span>
        <span>一级罗茨风机2</span>
      </div>
    </section>

    <section class="chart-grid">
      <ChartPanel
        v-for="panel in chartPanels"
        :key="panel.title"
        :title="panel.title"
        :blue="panel.blue"
        :gold="panel.gold"
        :green="panel.green"
      />
    </section>
  </section>
</template>

<script setup>
import DataBox from '../components/common/DataBox.vue';
import GaugeGroup from '../components/common/GaugeGroup.vue';
import ChartPanel from '../components/common/ChartPanel.vue';
import ProcessFlow from '../components/ProcessFlow.vue';
import { chartPanels, gauges, processMetrics } from '../data/dashboardData';

defineEmits(['openModal']);
</script>
