import { createApp } from 'vue';
import App from './App.vue';
import './styles/base.css';
import './styles/dashboard.css';

createApp(App).mount('#app');
